<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Production Credentials</label>
    <protected>false</protected>
    <values>
        <field>Access_Token__c</field>
        <value xsi:type="xsd:string">EAAAEDIlASWqGY7oRiw-N2QG3kuCMNTgFRlZPCK8-6H2OjqgyoXQSHoQ0sXA4Dl3</value>
    </values>
    <values>
        <field>Client_Id__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Client_Secret__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>EndPoint__c</field>
        <value xsi:type="xsd:string">https://connect.squareup.com/</value>
    </values>
    <values>
        <field>IsActive__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Square_Version__c</field>
        <value xsi:type="xsd:string">2023-09-13</value>
    </values>
</CustomMetadata>
