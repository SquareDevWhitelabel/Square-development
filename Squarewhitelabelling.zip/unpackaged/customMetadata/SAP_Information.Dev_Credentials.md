<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Dev Credentials</label>
    <protected>false</protected>
    <values>
        <field>EndPointURL__c</field>
        <value xsi:type="xsd:string">https://dpd.daikin.com.au/RESTAdapter/API/v1.0/square</value>
    </values>
    <values>
        <field>IsActive__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Password__c</field>
        <value xsi:type="xsd:string">ZLfbCV0mf1</value>
    </values>
    <values>
        <field>UserName__c</field>
        <value xsi:type="xsd:string">squaresfdev</value>
    </values>
</CustomMetadata>
