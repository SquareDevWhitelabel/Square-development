<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Sandbox Credentials</label>
    <protected>false</protected>
    <values>
        <field>Access_Token__c</field>
        <value xsi:type="xsd:string">EAAAEFymMS13bN_k6LJ7CxWP6CvSmZnxKDaUN8FqJoC5f2XR7BhTw4v-nQXSOfH_</value>
    </values>
    <values>
        <field>Client_Id__c</field>
        <value xsi:type="xsd:string">sandbox-sq0idb-OlF9pBt6j-WLOMKG8uV0jQ</value>
    </values>
    <values>
        <field>Client_Secret__c</field>
        <value xsi:type="xsd:string">sandbox-sq0csb-UV76UsdvkFV_qEiDceaKEpzqy5ihgWeGdvP802TCL9A</value>
    </values>
    <values>
        <field>EndPoint__c</field>
        <value xsi:type="xsd:string">https://connect.squareupsandbox.com/</value>
    </values>
    <values>
        <field>IsActive__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Square_Version__c</field>
        <value xsi:type="xsd:string">2023-01-19</value>
    </values>
</CustomMetadata>
